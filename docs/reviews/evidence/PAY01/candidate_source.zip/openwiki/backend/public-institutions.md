---
type: technical guide
title: Public institutions
description: Source-grounded guide to Public institutions ownership, behavior, invariants, and safe change paths.
tags: [ecosim, repository-navigation]
okf:
  title: Public institutions
  kind: subsystem
  status: grounded
  owners:
    - backend/agents.py
    - backend/economy.py
  sources:
    - backend/agents.py
    - backend/economy.py
    - backend/fiscal_guards.py
  tests:
    - backend/tests_contracts/test_contracts_bank.py
    - backend/tests_contracts/test_contracts_deposits.py
    - backend/tests_contracts/test_contracts_healthcare.py
    - backend/tests_contracts/test_contracts_housing_loans.py
    - backend/tests_contracts/test_contracts_housing_revenue.py
---

# Public institutions

EcoSim’s institutions are stateful agents plus coordinator-owned market machinery. `GovernmentAgent` and `BankAgent` live in `backend/agents.py`; `Economy` owns cross-agent settlement, healthcare queues, rental matching, stabilization, and diagnostics. Policy choice and mechanical execution are distinct: validated levers set parameters, while taxes, transfers, deposits, queues and contracts execute every tick.

```mermaid
flowchart TD
    HH["Households"] -->|wage taxes and deposits| GOV["GovernmentAgent"]
    GOV -->|transfers subsidies and public spending| HH
    FIRMS["Firms"] -->|profit property and investment taxes| GOV
    GOV -->|subsidies bailouts and public works| FIRMS
    HH -->|deposits and debt payments| BANK["BankAgent"]
    BANK -->|withdrawals interest and household credit| HH
    BANK -->|capital and mortgage credit| FIRMS
    FIRMS -->|rent and healthcare services| HH
```

*Figure 1. Institutional cash and service relationships; household taxes are aggregated into treasury settlement, while deposits and ordinary debt payments belong to the bank.*

## Government fiscal lifecycle

`GovernmentAgent` exposes bounded continuous tax rates and discrete levers for benefits, public works, minimum wage, subsidies, price/rent stabilization, infrastructure, technology, social spending and bailouts. `apply_policy_levers` maps options to numeric budgets/rates; `set_lever` validates the local action space. External proposals should also pass the canonical schema and fiscal guards rather than assigning fields directly.

Within `Economy.step()`:

1. pre-plan stabilizers may update commitments, execute eligible bailouts and manage public-works capacity;
2. sector subsidies are capped from trailing GDP and settle during purchases;
3. `plan_taxes` calculates progressive wage tax by wage percentiles, profit tax modifiers by firm cash percentiles, and housing property tax;
4. `plan_transfers` pays baseline unemployment benefits and proportionally fills low-cash gaps within the remaining transfer budget;
5. `apply_fiscal_results` adds wage/profit/property taxes and subtracts transfers;
6. infrastructure, technology, social programs, bond purchases, and investment tax settle later;
7. `_update_budget_pressure` computes the completed tick’s fiscal pressure and spending efficiency.

Government cash may become negative through transfers: the model treats the transfer budget as soft and permits deficits. By contrast, infrastructure and technology only spend when cash covers the configured outlay, and social spending is limited by available cash. Sustained pressure reduces spending effectiveness rather than imposing a hard balanced-budget constraint. Mechanical `adjust_policies` sizes transfer capacity; the legacy automatic chooser runs only when government stabilizers are enabled and LLM government is not enabled.

Baseline firms registered by `GovernmentAgent.register_baseline_firm` anchor essential sectors and follow special pricing/dividend/lifecycle rules. Public works creates/authorizes capacity conditionally and records requested, affordable, denied and job telemetry; it should not be reduced to a direct unemployment-number edit.

## Bank, deposits, and credit

`BankAgent` is optional. It tracks cash reserves, aggregate deposit liabilities, outstanding loans, credit scores and a loan ledger. `required_reserves = total_deposits * reserve_ratio`; `lendable_cash` is reserves above that requirement, and `can_lend` is the circuit breaker. Risk-adjusted rates rise as the `[0,1]` credit score falls; firm leverage is bounded relative to trailing revenue.

Loan origination appends a contract, increases outstanding repayment, and—unless government-backed—reduces reserves. Repayments reduce borrower cash and outstanding balances, replenish reserves for ordinary loans, and update scores; repeated misses/defaults can cause write-offs. Government-backed emergency loans debit government cash and are tracked by the bank without a second reserve disbursement.

Deposits are deliberately two-sided: the household owns `bank_deposit`, while the bank tracks only aggregate `total_deposits`. All withdrawals must call `BankAgent.withdraw` and then reduce the household balance. Before goods clearing, `_withdraw_deposits_for_planned_consumption` provides liquidity; rent/health payments can use `_ensure_cash_for_payment`; end-of-tick `_process_bank_deposits` sweeps excess cash, adjusts the deposit rate and pays only sustainable interest from lending income above a retained margin. Directly editing either side breaks the accounting invariant.

## Healthcare

Healthcare is a queue/capacity system, not a storable good. Households deterministically sample annual visit plans from health buckets, enqueue due requests, and cannot be duplicated while already queued. `Economy._prioritize_healthcare_queue` and `_healthcare_effective_capacity` triage against doctor/resident capacity. `_process_healthcare_services` checks available slots and affordability, can issue medical credit, records provider receipts and queue events, and applies planned healing. Firm healthcare inventory must remain zero.

The workforce pipeline uses `medical_training_status` values `none`, `student`, `resident`, and `doctor`, training time, medical-school debt and role-specific capacity. Ordinary private hiring is disabled for healthcare firms in `Economy.step()`. The optional doctor-health lock restores doctor health before and after service/wellbeing phases; it is a model policy, not clinical realism.

Queue depth, attempted slots, completions, affordability rejects, wait time and unmet care distinguish demand from realized treatment. A sector subsidy reduces patient price subject to the government’s subsidy cap; it does not itself create doctor capacity.

## Housing

Housing combines a specialized rental market, firm-owned unit capacity, repairs, property taxation and expansion finance:

- `_clear_housing_rental_market` maintains contracts, attempts payment using cash and accessible deposits, evicts/clears contracts when required, and matches unhoused households to available firm units.
- Active renters have `met_housing_need = True`; rent is firm revenue and household spending, separate from storable housing-good inventory.
- `_apply_housing_repairs` restores damaged/maintenance state and routes costs through the modeled economy.
- `FirmAgent.invest_in_unit_expansion` can self-finance units; construction cost is routed to miscellaneous redistribution.
- `_service_housing_mortgage_debt` runs before `_offer_housing_expansion_loans`. `LoanContract` uses amortizing PMT from `Economy._compute_housing_pmt`; underwriting tests cover DSCR/LTV gates, principal/interest split and money movement.
- Rent stabilization caps increases and records `rent_increase_limited_count`; property tax uses annualized rental income as an assessed-value proxy.

Housing firms therefore participate in general firm planning but use specialized rental and finance resolution after goods clearing. Unit capacity, occupied units, rental contracts and household flags must agree.

## Institutional invariants

- Fiscal plans are snapshots; aggregate government settlement occurs after market outcomes.
- Subsidy disbursement cannot exceed the per-tick cap/remaining envelope, and bailout accounting cannot exceed the active cycle budget.
- Loan and deposit totals remain nonnegative; ordinary loans cannot spend required reserves.
- Household deposit and bank liability changes are paired through bank methods.
- Healthcare visits do not exceed effective capacity and do not create inventory.
- One household has at most one active healthcare queue placement and one rental provider.
- Housing PMT amortizes principal at zero interest and exceeds principal over a positive-rate term.

## Focused verification

```bash
python -m pytest backend/tests_contracts/test_contracts_bank.py
python -m pytest backend/tests_contracts/test_contracts_deposits.py
python -m pytest backend/tests_contracts/test_contracts_healthcare.py
python -m pytest backend/tests_contracts/test_contracts_housing_loans.py
python -m pytest backend/tests_contracts/test_contracts_housing_revenue.py
```

See [Tick lifecycle](tick-lifecycle.md) for ordering and [Agents and markets](agents-and-markets.md) for household/firm decisions. These tests establish simulator accounting and behavioral contracts; they do not demonstrate that fiscal multipliers, underwriting, care outcomes, or housing institutions match any real jurisdiction..